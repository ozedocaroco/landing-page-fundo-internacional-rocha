"use client"

import { Linkedin, Mail, Phone } from "lucide-react"

export function FooterSection() {
  return (
    <footer className="w-full max-w-[1320px] mx-auto px-5 flex flex-col gap-8 py-10 md:py-[70px] border-t-2 border-primary/20">
      {/* Top Section: Logo and Description */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-8 md:gap-0">
        <div className="flex flex-col justify-start items-start gap-6 p-4 md:p-8 max-w-md">
          <div className="flex gap-3 items-center">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 3L14 8L19 9L15 13L16 19L12 16L8 19L9 13L5 9L10 8L12 3Z" fill="white" />
              </svg>
            </div>
            <div className="text-foreground text-2xl font-bold">Rocha</div>
          </div>
          <p className="text-muted-foreground text-sm font-normal leading-relaxed">
            Especialista em estratégias sofisticadas com opções internacionais, oferecendo aos investidores acesso a
            mercados globais com gestão ativa e risco controlado.
          </p>
          <div className="flex justify-start items-start gap-4">
            <a
              href="#"
              aria-label="LinkedIn"
              className="w-5 h-5 flex items-center justify-center hover:text-primary transition-colors"
            >
              <Linkedin className="w-full h-full text-muted-foreground hover:text-primary transition-colors" />
            </a>
            <a
              href="mailto:contato@rochaopcoes.com.br"
              aria-label="Email"
              className="w-5 h-5 flex items-center justify-center"
            >
              <Mail className="w-full h-full text-muted-foreground hover:text-primary transition-colors" />
            </a>
            <a href="tel:+5511999999999" aria-label="Phone" className="w-5 h-5 flex items-center justify-center">
              <Phone className="w-full h-full text-muted-foreground hover:text-primary transition-colors" />
            </a>
          </div>
        </div>

        {/* Right Section: Links */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-8 md:gap-12 p-4 md:p-8 w-full md:w-auto">
          <div className="flex flex-col justify-start items-start gap-3">
            <h3 className="text-muted-foreground text-sm font-bold leading-5 uppercase tracking-wide">Investimento</h3>
            <div className="flex flex-col justify-end items-start gap-2">
              <a
                href="#beneficios-section"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Estratégia
              </a>
              <a
                href="#como-funciona"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Como Funciona
              </a>
              <a
                href="#faq-section"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                FAQ
              </a>
              <a
                href="#contato"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Contato
              </a>
            </div>
          </div>
          <div className="flex flex-col justify-start items-start gap-3">
            <h3 className="text-muted-foreground text-sm font-bold leading-5 uppercase tracking-wide">Empresa</h3>
            <div className="flex flex-col justify-center items-start gap-2">
              <a
                href="https://maisretorno.com/gestores/rocha-opcoes-de-investimentos"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Sobre a Rocha
              </a>
              <a
                href="#"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Outros Fundos
              </a>
              <a
                href="#"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Regulamentação CVM
              </a>
            </div>
          </div>
          <div className="flex flex-col justify-start items-start gap-3">
            <h3 className="text-muted-foreground text-sm font-bold leading-5 uppercase tracking-wide">Legal</h3>
            <div className="flex flex-col justify-center items-start gap-2">
              <a
                href="#"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Termos de Uso
              </a>
              <a
                href="#"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Política de Privacidade
              </a>
              <a
                href="#"
                className="text-foreground text-sm font-normal leading-5 hover:text-primary transition-colors"
              >
                Documentos CVM
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Legal Disclaimer */}
      <div className="border-t-2 border-primary/20 pt-8">
        <p className="text-muted-foreground text-xs leading-relaxed max-w-4xl">
          <strong className="text-foreground">Aviso Legal:</strong> Investimentos em fundos multimercado com derivativos
          envolvem riscos significativos, incluindo risco de mercado, risco cambial e possibilidade de perda substancial
          do capital investido. A rentabilidade passada não representa garantia de resultados futuros. Este material tem
          caráter meramente informativo e não constitui oferta ou recomendação de investimento. Leia atentamente o
          regulamento e o formulário de informações complementares antes de investir. Fundo regulamentado pela CVM.
        </p>
        <p className="text-muted-foreground text-xs mt-4">
          © 2025 Rocha Opções de Investimentos. Todos os direitos reservados. | CNPJ: 61.748.792/0001-71
        </p>
      </div>
    </footer>
  )
}

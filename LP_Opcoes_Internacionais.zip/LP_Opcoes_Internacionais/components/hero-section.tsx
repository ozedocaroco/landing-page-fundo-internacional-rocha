import { Button } from "@/components/ui/button"
import { Header } from "./header"
import Link from "next/link"
import { TrendingUp } from "lucide-react"

export function HeroSection() {
  return (
    <section className="flex flex-col items-center text-center relative mx-auto overflow-hidden my-6 px-4 w-full">
      <div className="absolute inset-0 z-0 overflow-hidden">
        {/* Wave pattern background inspired by growth chart */}
        <svg
          className="absolute w-full h-full opacity-5"
          viewBox="0 0 1200 800"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
        >
          <path d="M0 400 Q 300 200 600 400 T 1200 400 V 800 H 0 Z" fill="url(#wave-gradient)" opacity="0.3" />
          <path d="M0 500 Q 300 300 600 500 T 1200 500 V 800 H 0 Z" fill="url(#wave-gradient)" opacity="0.2" />
          <defs>
            <linearGradient id="wave-gradient" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="hsl(var(--primary))" />
              <stop offset="50%" stopColor="hsl(var(--secondary))" />
              <stop offset="100%" stopColor="hsl(var(--accent))" />
            </linearGradient>
          </defs>
        </svg>

        {/* Subtle grid overlay */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(hsl(var(--foreground) / 0.03) 1px, transparent 1px),
                           linear-gradient(90deg, hsl(var(--foreground) / 0.03) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      {/* Header */}
      <div className="relative z-20 w-full">
        <Header />
      </div>

      <div className="relative z-10 space-y-6 mb-8 max-w-4xl mt-16 md:mt-24 lg:mt-32 px-4">
        <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-primary/10 border border-primary/30 mb-4">
          <TrendingUp className="w-4 h-4 text-primary" />
          <span className="text-primary text-sm font-bold">Multimercado</span>
          <span className="text-muted-foreground text-sm">•</span>
          <span className="text-foreground text-sm font-medium">Opções Internacionais</span>
        </div>

        <h1 className="text-foreground text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
          Seus investimentos estão preparados para volatilidade global?
        </h1>

        <p className="text-muted-foreground text-lg md:text-xl font-normal leading-relaxed max-w-3xl mx-auto text-pretty">
          Enquanto o mercado oscila, investidores sofisticados diversificam com estratégias em opções internacionais
          para proteger patrimônio e capturar oportunidades globais.
        </p>
      </div>

      <Link href="#contato" className="scroll-smooth relative z-10">
        <Button className="bg-primary text-primary-foreground hover:bg-primary-dark px-8 py-6 rounded-full font-bold text-base shadow-xl ring-2 ring-primary/20 transition-all hover:scale-105">
          Conhecer estratégia internacional
        </Button>
      </Link>

      {/* Decorative lion icon inspired element - subtle */}
      <div className="absolute right-10 top-1/2 -translate-y-1/2 opacity-5 hidden lg:block">
        <svg width="200" height="200" viewBox="0 0 200 200" fill="none">
          <path
            d="M100 50 L120 80 L150 70 L130 100 L160 110 L130 130 L140 160 L100 140 L60 160 L70 130 L40 110 L70 100 L50 70 L80 80 Z"
            fill="hsl(var(--primary))"
          />
        </svg>
      </div>
    </section>
  )
}
